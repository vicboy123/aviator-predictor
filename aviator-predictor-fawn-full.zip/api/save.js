export default function handler(req, res) {
  if (req.method === 'POST') {
    const { result } = req.body;
    console.log('Saving result:', result);
    res.status(200).json({ message: 'Saved' });
  } else {
    res.status(405).json({ message: 'Method not allowed' });
  }
}
