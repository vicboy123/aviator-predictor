export default function handler(req, res) {
  const prediction = (Math.random() * (20 - 1) + 1).toFixed(2); // Random 1x to 20x
  res.status(200).json({ prediction });
}
