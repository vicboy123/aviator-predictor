export default function handler(req, res) {
  const sampleData = [
    { time: "10:00 AM", result: "2.45x" },
    { time: "10:06 AM", result: "5.23x" },
  ];
  res.status(200).json({ recent: sampleData });
}
